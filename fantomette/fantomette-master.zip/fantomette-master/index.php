<?php
header('Location: fantomette/');
?>
