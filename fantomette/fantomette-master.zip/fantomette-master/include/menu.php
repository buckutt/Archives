<ul>
<li><a href="<?=$util->makeUrl('bar.php?id_bar='.$_SESSION['id_bar'])?>">Bar</a></li>
<li><a href="<?=$util->makeUrl('dialog.php')?>">Dialogue</a></li>
<li><a href="<?=$util->makeUrl('admin/trezo.php')?>">Trezo</a></li>
<li><a href="<?=$util->makeUrl('admin/bar.php')?>">Admin Bar</a></li>
<li><a href="<?=$util->makeUrl('admin/bar.php')?>">Admin Bar</a></li>
<li><a href="<?=$util->makeUrl('admin/histobar.php')?>">Histo-Bar</a></li>
<li><a href="<?=$util->makeUrl('admin/prob.php?type=1')?>">Problemmes Type Trezo</a></li>
<li><a href="<?=$util->makeUrl('admin/prob.php?type=2')?>">Problemmes Type Logistique</a></li>
<li><a href="<?=$util->makeUrl('admin/prob.php?type=3')?>">Problemmes Type Securite</a></li>
</ul>
