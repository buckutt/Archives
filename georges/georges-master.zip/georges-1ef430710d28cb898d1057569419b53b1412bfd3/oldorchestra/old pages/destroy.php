<?php

session_destroy();
?>
