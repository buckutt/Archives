<?php

require_once "php/class/Page.class.php";

$page = new Page("tesst");
$page->topMenu();


$page->sideMenu();
?>
