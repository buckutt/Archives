<?php

$CONF = array(
	"title" => "payutc", 
	"rechargement_min" => 10.0,  // TODO  NE FAUDRAIT-IL DEMANDER CES VALEURS DIRECTEMENT AU SERVEUR ?
	"rechargement_max" => 100.0, 
	"casper_url" => "http://assos.utc.fr/casper/",
	"cas_url" => "https://cas.utc.fr/cas",
	"soap_url" => "https://assos.utc.fr/buckutt/SADMIN.class.php?wsdl"
 	);
