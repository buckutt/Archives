BuckUTT est un système de paiement avec porte-monnaie électronique, d'architecture client/serveur (basé sur des web services).

Ceci est la partie serveur.

* Serveur en php / Zend pour la partie SOAP

Elle comprend plusieurs Webservices :

* BADMIN
Administration de buckutt
* FADMIN
Administration d'une fondation
* PBUY
Vendre a une autre personne que soi
* SADMIN
Administrer son compte
* SBUY
S'acheter un objet


Il existe aussi:

*   buckutt/georges
Pour la gestion administrative en php (pre-release, non fonctionel)
*   buckutt/peggy 
En java/soap en client pour interface tactile
*   buckutt/server
*   buckutt/pauline
Point de vente sous Android 
*   buckutt/casper
*   buckutt/mozart
*   buckutt/fantomette
En php pour la gestion de son compte via internet


Les concepts

*  fundation => une fundation est : une asso ou un club ou autre truc du genre qui peut proposer des objets à vendre !
*  point => est un point de vente (foyer, BDE, rue, ...)
*  vendeur => est un permanancier de vente 
*  groupe => un étudiant appartient forcément à 1 groupe, il peut appartenir a plein de groupes (ex de groupe: cotisant BDE, cotisant UNG, étudiant UTT, exterieur UTT...)
*  credit => c'est le prix, mais ramené à un entier, peut être en euros ou pas! !! 
*  objet => [a expliquer]

